// APE 1 - Codigo 2: el mismo Blink, ahora escribiendo registros
// Placa: Arduino UNO (ATmega328P @ 16 MHz) - simulacion en Wokwi
// Regla: no se usa pinMode() ni digitalWrite()
void setup() {
 DDRB |= (1 << DDB5); // PB5 (D13) como salida; los demás bits no cambian
}
void loop() {
 PINB = (1 << PINB5); // Escribir 1 en PINB5 conmuta PB5
 delay(500); // 500 ms encendido / 500 ms apagado
}