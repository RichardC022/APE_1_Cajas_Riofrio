// APE 1 - Codigo 2: el mismo Blink, ahora escribiendo registros
// Placa: Arduino UNO (ATmega328P @ 16 MHz) - simulacion en Wokwi
// Regla: no se usa pinMode() ni digitalWrite()
void setup() {
 DDRB |= (1 << DDB5); // PB5 (D13) como salida; los demás bits no cambian
}
void loop() {
 PORTB |= (1 << PORTB5); // Enciende el LED
 delay(500); // Espera 500 ms 
 PORTB &= ~(1 << PORTB5); // Apaga el LED
 delay(500); // Espera 500 ms 
}
